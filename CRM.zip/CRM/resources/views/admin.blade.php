@extends('layouts.master')

@section('content')
    <div class="container">
        <div class="row" style="margin-top: 50px">
            <div class="col-6" style="margin: auto;">

                <form method="POST" action="/admin" enctype="multipart/form-data">
                    {{csrf_field()}}
                	<div class="form-group">
                		<label for="formGroupExampleInput">Название проекта</label>
                		<input type="text" class="form-control" name="title" id="formGroupExampleInput">
                	</div>
                	<div class="form-group">
                		<label for="formGroupExampleInput">Сколько этажей?</label>
                		<input type="number" name="floor" class="form-control" id="formGroupExampleInput" placeholder="10">
                	</div>
                	<div class="form-group">
                		<label for="formGroupExampleInput2">Сколько квартир в<strong> каждом </strong>этаже?</label>
                		<input type="number" name="apartment" class="form-control" id="formGroupExampleInput2" placeholder="5">
                	</div>
                	<div class="text-center">
                		<button type="submit" class="btn btn-primary">Создать</button>
                	</div>
                </form>

            </div>
        </div>

    @foreach($proj as $project)
        {{$project->name}}
    @endforeach


    </div>
@endsection
