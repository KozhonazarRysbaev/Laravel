@extends('layouts.master')

@section('content')
    <div class="container">
        <div class="row">
            <div class="col-4" style="margin: auto;">
                
				<table class="table table-striped">
				  <thead>
				    <tr>
				      <th scope="col">#</th>
				      <th scope="col">Проекты</th>
				    </tr>
				  </thead>
				  <tbody>

					  <?php $i = 1; ?>
					  
					  @foreach($project as $projects)
					    
					    <tr>
					      <th scope="row">{{ $i }}</th>
					      <td><a href="/dashboard/{{$projects->id}}">{{$projects->name}}</a></td>
					      <td style="display: none;"> {{ $i++ }}</td>
					    </tr>
					    
					  @endforeach

				  </tbody>
				</table>

            </div>
        </div>
    </div>
@endsection
