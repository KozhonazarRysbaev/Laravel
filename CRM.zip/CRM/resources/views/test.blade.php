@extends('layouts.master')

@section('content')


@foreach($test->apartments as $floor)

@endforeach


@endsection