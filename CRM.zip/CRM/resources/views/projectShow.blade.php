@extends('layouts.master')

@section('content')
	
	<div class="container-fluid">
		<div class="row">
			<div class="col-12">
				<div style="margin: 30px auto;"><h2 style="text-align: center;">{{$project->name}}</h2></div>

				<table class="table table-bordered">
					<tbody>

						@foreach($floor->floors as $floors)					

						<tr>
						<th style="width: 85px">{{$floors->floor}} этаж</th>

							@foreach($floors->apartments as $apartments)

							@if($apartments->satus == true)
								<script type="text/javascript">
										document.getElementById("btn-primary1").className = "btn-danger";
								</script>
							@endif

								
							  <td style="text-align: center;">Кв.№{{$apartments->room_num}}<br>
								<button id="btn-primary1" type="button" class="btn-sm btn-primary" data-toggle="modal" data-target="#{{$apartments->id}}">Продать</button>

								<div class="modal fade" id="{{$apartments->id}}" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
								  <div class="modal-dialog modal-dialog-centered" role="document">
								    <div class="modal-content">
								      <div class="modal-body">
										<h4>Кв.№ {{$apartments->room_num}}</h4>

								      	<form method="POST" action="{{action('DashboardController@update', $apartments->id)}}" enctype="multipart/form-data" id="{{$apartments->id}}">

								      		{{csrf_field()}}
											
								      		<div class="form-group">
								      			<textarea class="form-control" name="comment" id="exampleFormControlTextarea1" rows="2" placeholder="Комментарий (Не обьязательно)"></textarea><br>
								      		<input type="submit" class="btn-sm btn-success" value="Продать" id="{{$apartments->id}}" />
								      		</div>
								      	</form>
										
								      </div>
								    </div>
								  </div>
								</div>
								
							  </td>


							

							@endforeach
							
						</tr>

						@endforeach

					</tbody>
				</table>

			</div>
		</div>
	</div>
	




@endsection
