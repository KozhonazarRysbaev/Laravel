<?php $__env->startSection('content'); ?>
	
	<div class="container-fluid">
		<div class="row">
			<div class="col-12">
				<div style="margin: 30px auto;"><h2 style="text-align: center;"><?php echo e($project->name); ?></h2></div>

				<table class="table table-bordered">
					<tbody>

						<?php $__currentLoopData = $floor->floors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $floors): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>					

						<tr>
						<th style="width: 85px"><?php echo e($floors->floor); ?> этаж</th>

							<?php $__currentLoopData = $floors->apartments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $apartments): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

							<?php if($apartments->satus == true): ?>
								<script type="text/javascript">
										document.getElementById("btn-primary1").className = "btn-danger";
								</script>
							<?php endif; ?>

								
							  <td style="text-align: center;">Кв.№<?php echo e($apartments->room_num); ?><br>
								<button id="btn-primary1" type="button" class="btn-sm btn-primary" data-toggle="modal" data-target="#<?php echo e($apartments->id); ?>">Продать</button>

								<div class="modal fade" id="<?php echo e($apartments->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
								  <div class="modal-dialog modal-dialog-centered" role="document">
								    <div class="modal-content">
								      <div class="modal-body">
										<h4>Кв.№ <?php echo e($apartments->room_num); ?></h4>

								      	<form method="POST" action="<?php echo e(action('DashboardController@update', $apartments->id)); ?>" enctype="multipart/form-data" id="<?php echo e($apartments->id); ?>">

								      		<?php echo e(csrf_field()); ?>

											
								      		<div class="form-group">
								      			<textarea class="form-control" name="comment" id="exampleFormControlTextarea1" rows="2" placeholder="Комментарий (Не обьязательно)"></textarea><br>
								      		<input type="submit" class="btn-sm btn-success" value="Продать" id="<?php echo e($apartments->id); ?>" />
								      		</div>
								      	</form>
										
								      </div>
								    </div>
								  </div>
								</div>
								
							  </td>


							

							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							
						</tr>

						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

					</tbody>
				</table>

			</div>
		</div>
	</div>
	




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>