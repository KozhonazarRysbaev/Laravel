<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row" style="margin-top: 50px">
            <div class="col-6" style="margin: auto;">

                <form method="POST" action="/admin" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                	<div class="form-group">
                		<label for="formGroupExampleInput">Название проекта</label>
                		<input type="text" class="form-control" name="title" id="formGroupExampleInput">
                	</div>
                	<div class="form-group">
                		<label for="formGroupExampleInput">Сколько этажей?</label>
                		<input type="number" name="floor" class="form-control" id="formGroupExampleInput" placeholder="10">
                	</div>
                	<div class="form-group">
                		<label for="formGroupExampleInput2">Сколько квартир в<strong> каждом </strong>этаже?</label>
                		<input type="number" name="apartment" class="form-control" id="formGroupExampleInput2" placeholder="5">
                	</div>
                	<div class="text-center">
                		<button type="submit" class="btn btn-primary">Создать</button>
                	</div>
                </form>

            </div>
        </div>

    <?php $__currentLoopData = $proj; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($project->name); ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>