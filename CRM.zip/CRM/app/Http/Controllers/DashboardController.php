<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Project;
use App\Floor;
use App\Apartment;
use Auth;

class DashboardController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */

    public function index(){

        $project = Project::with('Floors')->get();
        return view ('dashboard', compact('project')); 

    }


    public function update(Request $request, $id){
        $apartment_upd = Apartment::find($id);
        $apartment_upd->comment = $request->get('comment');
        $apartment_upd->status = true;
        $apartment_upd->sold_by = Auth::user()->name;
        $apartment_upd->save();

        return redirect()->back();

    }

    public function projectShow($id){

        $project = Project::find($id);
        $floor = Project::with('Floors')->find($id);
        $apartment = Floor::with('Apartments')->find($id);
        $apartment_upd = Apartment::find($id);
        return view('projectShow', compact('floor', 'apartment', 'project', 'apartment_upd'));

    }

}
