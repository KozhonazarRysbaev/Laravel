<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Project;
use App\Floor;
use App\Apartment;

class ProjectsController extends Controller {

    public function store(Request $request) {

        $project = new Project;
        $project->name = $request->title;
        $project->save();

        $floor_input = $request->floor;
        $apart = $request->apartment;


        for ($i=1; $i <= $floor_input; $i++) {

                $floor = new Floor;
                $floor->floor = $i;
                $floor->project_id = $project->id;
                $floor->save();
                
            for ($j=1; $j <= $apart; $j++) {

                $apartment = new Apartment;
                $apartment->room_num = $j;
                $apartment->floor_id = $i;
                $apartment->save();
                
        	}

        }

        return redirect('/admin');

    }





}
