<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Floor extends Model
{
    
    public function projects(){
    	return $this->belongsTo('App\Project');
    }

    public function apartments(){
    	return $this->hasMany('App\Apartment');
    }
}
